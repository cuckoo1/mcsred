/*========================================================*/
/*                                                        */
/*  swap.h          2015.05.11      version 0.2.0         */
/*                                                        */
/*  Copyright (C) 2003-2010 Wojtek Pych, CAMK PAN         */
/*                                                        */
/*  Written for GNU project C and C++ Compiler            */
/*                                                        */
/*========================================================*/

extern int  needswap(void);
extern void swap_bytes(void *, int, int);

/*** END ***/
