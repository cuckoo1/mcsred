#!/bin/csh
# http://iraf.net/forum/viewtopic.php?showtopic=1465531
if (-e uparm) then
mkiraf << EOF_MIRAF1 >& /dev/null
y
xgterm
EOF_MKIRAF1
else

mkiraf << EOF_MKIRAF2 >& /dev/null
xgterm
EOF_MKIRAF2

endif
